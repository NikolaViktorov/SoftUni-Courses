﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03._Wild_Farm.Animals.Mammal.Feline
{
    public abstract class Feline : Mammal
    {
        public abstract string Breed { get; set; }
    }
}
