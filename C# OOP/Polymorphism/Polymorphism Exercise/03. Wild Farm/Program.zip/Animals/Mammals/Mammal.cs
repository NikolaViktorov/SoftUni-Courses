﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03._Wild_Farm.Animals.Mammal
{
    public abstract class Mammal : Animal
    {
        public abstract string LivingRegion { get; set; }
    }
}
