﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03._Wild_Farm.Animals.Birds
{
    public abstract class Bird : Animal
    {
        public abstract double WingSize { get; set; }
    }
}
