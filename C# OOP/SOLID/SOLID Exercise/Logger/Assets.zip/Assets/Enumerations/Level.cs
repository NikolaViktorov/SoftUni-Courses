﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logger.Assets.Enumerations
{
    public enum Level
    {
        INFO,
        WARNING,
        ERROR,
        CRITICAL,
        FATAL
    }
}
