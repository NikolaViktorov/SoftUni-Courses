﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logger.Assets.Contracts
{
    public interface ILayout
    {
        string Format { get; }
    }
}
