﻿namespace Zoo
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class StartUp
    {
        public static void Main(string[] args)
        {

        }
    }
}